package com.diu.busapp.model;

public class User {
    private int id;
    private String name;
    private String phone;
    private String password;
    private String role;

    public User(String name, String phone, String password, String role) {
        this.name = name;
        this.phone = phone;
        this.password = password;
        this.role = role;
    }

    // Getters and Setters
    public String getName() { return name; }
    public String getPhone() { return phone; }
    public String getPassword() { return password; }
    public String getRole() { return role; }
}
