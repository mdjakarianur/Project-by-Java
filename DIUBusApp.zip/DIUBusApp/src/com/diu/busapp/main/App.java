package com.diu.busapp.main;

import com.diu.busapp.ui.LoginForm;

public class App {
    public static void main(String[] args) {
        new LoginForm();
    }
}
