package com.diu.busapp.ui;

import javax.swing.*;
import java.awt.*;

public class DashboardTransporter extends JFrame {
    public DashboardTransporter(String transporterName) {
        setTitle("Transporter Dashboard - " + transporterName);
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 1));

        JButton addBusBtn = new JButton("Add New Bus");
        JButton updateLocationBtn = new JButton("Update Bus Location");
        JButton logoutBtn = new JButton("Logout");

        add(new JLabel("Hello, " + transporterName, JLabel.CENTER));
        add(addBusBtn);
        add(updateLocationBtn);
        add(logoutBtn);

        logoutBtn.addActionListener(e -> {
            dispose();
            new LoginForm().setVisible(true);
        });

        addBusBtn.addActionListener(e -> new AddBusForm().setVisible(true));
        updateLocationBtn.addActionListener(e -> new UpdateBusLocationForm().setVisible(true));
    }
}
