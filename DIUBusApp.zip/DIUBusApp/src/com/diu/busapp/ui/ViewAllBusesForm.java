package com.diu.busapp.ui;

import com.diu.busapp.db.DatabaseConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class ViewAllBusesForm extends JFrame {
    public ViewAllBusesForm() {
        setTitle("All Buses");
        setSize(500, 300);
        setLocationRelativeTo(null);

        JTable table = new JTable();
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"ID", "Name", "Route", "Latitude", "Longitude"});
        table.setModel(model);

        try (Connection conn = DatabaseConnection.getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM buses");
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("route"),
                        rs.getDouble("lat"),
                        rs.getDouble("lon")
                });
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        add(new JScrollPane(table));
    }
}
