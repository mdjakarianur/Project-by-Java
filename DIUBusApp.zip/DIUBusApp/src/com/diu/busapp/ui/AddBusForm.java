package com.diu.busapp.ui;

import com.diu.busapp.db.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class AddBusForm extends JFrame {
    public AddBusForm() {
        setTitle("Add New Bus");
        setSize(300, 250);
        setLayout(new GridLayout(5, 1));
        setLocationRelativeTo(null);

        JTextField nameField = new JTextField();
        JTextField routeField = new JTextField();
        JButton saveBtn = new JButton("Save");

        add(new JLabel("Bus Name:"));
        add(nameField);
        add(new JLabel("Route:"));
        add(routeField);
        add(saveBtn);

        saveBtn.addActionListener(e -> {
            String name = nameField.getText();
            String route = routeField.getText();

            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "INSERT INTO buses (name, route) VALUES (?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, name);
                stmt.setString(2, route);
                stmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Bus added successfully.");
                dispose();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
    }
}
