package com.diu.busapp.ui;

import com.diu.busapp.db.DatabaseConnection;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class UpdateBusLocationForm extends JFrame {
    public UpdateBusLocationForm() {
        setTitle("Update Bus Location");
        setSize(300, 250);
        setLayout(new GridLayout(5, 1));
        setLocationRelativeTo(null);

        JTextField nameField = new JTextField();
        JTextField latField = new JTextField();
        JTextField lonField = new JTextField();
        JButton updateBtn = new JButton("Update");

        add(new JLabel("Bus Name:"));
        add(nameField);
        add(new JLabel("Latitude:"));
        add(latField);
        add(new JLabel("Longitude:"));
        add(lonField);
        add(updateBtn);

        updateBtn.addActionListener(e -> {
            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "UPDATE buses SET lat=?, lon=? WHERE name=?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setDouble(1, Double.parseDouble(latField.getText()));
                stmt.setDouble(2, Double.parseDouble(lonField.getText()));
                stmt.setString(3, nameField.getText());
                int rows = stmt.executeUpdate();

                if (rows > 0) {
                    JOptionPane.showMessageDialog(this, "Location updated.");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Bus not found.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
    }
}
