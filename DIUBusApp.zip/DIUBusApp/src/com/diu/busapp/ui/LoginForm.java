package com.diu.busapp.ui;

import com.diu.busapp.service.UserService;

import javax.swing.*;
import java.awt.*;

public class LoginForm extends JFrame {
    private final JTextField phoneField;
    private final JPasswordField passwordField;
    private final UserService userService;

    public LoginForm() {
        super("User Login");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 2));

        userService = new UserService();

        phoneField = new JTextField();
        passwordField = new JPasswordField();

        JButton loginBtn = new JButton("Login");
        JButton registerBtn = new JButton("Register");

        add(new JLabel("Phone:")); add(phoneField);
        add(new JLabel("Password:")); add(passwordField);
        add(loginBtn); add(registerBtn);

        loginBtn.addActionListener(e -> {
            String phone = phoneField.getText();
            String password = new String(passwordField.getPassword());

            if (userService.login(phone, password)) {
                JOptionPane.showMessageDialog(this, "Login Successful!");
                // open dashboard or home
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials.");
            }
        });

        registerBtn.addActionListener(e -> {
            dispose();
            new RegisterForm();
        });

        setVisible(true);
    }
}
