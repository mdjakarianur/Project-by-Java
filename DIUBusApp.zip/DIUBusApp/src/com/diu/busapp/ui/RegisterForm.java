package com.diu.busapp.ui;

import com.diu.busapp.model.User;
import com.diu.busapp.service.UserService;

import javax.swing.*;
import java.awt.*;

public class RegisterForm extends JFrame {
    private final JTextField nameField;
    private final JTextField phoneField;
    private final JPasswordField passwordField;
    private final JComboBox<String> roleBox;
    private final UserService userService;

    public RegisterForm() {
        super("User Registration");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 2));

        userService = new UserService();

        nameField = new JTextField();
        phoneField = new JTextField();
        passwordField = new JPasswordField();
        roleBox = new JComboBox<>(new String[]{"user", "transporter"});

        JButton registerBtn = new JButton("Register");
        JButton backBtn = new JButton("Back to Login");

        add(new JLabel("Name:")); add(nameField);
        add(new JLabel("Phone:")); add(phoneField);
        add(new JLabel("Password:")); add(passwordField);
        add(new JLabel("Role:")); add(roleBox);
        add(registerBtn); add(backBtn);

        registerBtn.addActionListener(e -> {
            String name = nameField.getText();
            String phone = phoneField.getText();
            String password = new String(passwordField.getPassword());
            String role = (String) roleBox.getSelectedItem();

            if (name.isEmpty() || phone.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required!");
                return;
            }

            User user = new User(name, phone, password, role);
            if (userService.registerUser(user)) {
                JOptionPane.showMessageDialog(this, "Registered Successfully!");
                dispose();
                new LoginForm();
            } else {
                JOptionPane.showMessageDialog(this, "User already exists or error occurred!");
            }
        });

        backBtn.addActionListener(e -> {
            dispose();
            new LoginForm();
        });

        setVisible(true);
    }
}
