package com.diu.busapp.ui;

import javax.swing.*;
import java.awt.*;

public class DashboardUser extends JFrame {
    public DashboardUser(String userName) {
        setTitle("User Dashboard - Welcome " + userName);
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(5, 1));

        JButton searchRouteBtn = new JButton("Search Route");
        JButton viewAllRoutesBtn = new JButton("View All Buses");
        JButton logoutBtn = new JButton("Logout");

        add(new JLabel("Welcome " + userName, JLabel.CENTER));
        add(searchRouteBtn);
        add(viewAllRoutesBtn);
        add(logoutBtn);

        logoutBtn.addActionListener(e -> {
            dispose();
            new LoginForm().setVisible(true);
        });

        viewAllRoutesBtn.addActionListener(e -> new ViewAllBusesForm().setVisible(true));
    }
}
